echo -n "example +6285\nMasukkan No : "
read pil;

ulang="y"

while [ $ulang = "y" ]
do
  python main.py $pil
done
