#!/system/xbin/bash

u="y"

while [ $u = "y" ]
do

python Visit.py -p +13855191175 -c doge
python Visit.py -p +13857774475 -c doge
python Visit.py -p +13852633341 -c doge
python Visit.py -p +13852336643 -c doge
python Visit.py -p +13025034101 -c doge
python Visit.py -p +13024708984 -c doge
python Visit.py -p +13023081806 -c doge
python Visit.py -p +13855191688 -c doge
python Visit.py -p +13855191489 -c doge
python Visit.py -p +13854485490 -c doge
python Visit.py -p +13853000553 -c doge
python Visit.py -p +13852633871 -c doge
python Visit.py -p +13026080388 -c doge
python Visit.py -p +13015392989 -c doge
python Visit.py -p +13852693682 -c doge
python Visit.py -p +13852635934 -c doge
done